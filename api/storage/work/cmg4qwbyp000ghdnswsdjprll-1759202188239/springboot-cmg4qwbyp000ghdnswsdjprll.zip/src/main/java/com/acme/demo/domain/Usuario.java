package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;






@Entity
@Table(name = "usuario")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Usuario implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;
  @Column(name = "librosId", nullable = false)
  private java.util.UUID librosId;
}
