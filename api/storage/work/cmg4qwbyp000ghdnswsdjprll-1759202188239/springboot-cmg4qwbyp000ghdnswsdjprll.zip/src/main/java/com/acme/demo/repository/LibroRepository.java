package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Libro;

public interface LibroRepository extends JpaRepository<Libro, java.util.UUID> {}
