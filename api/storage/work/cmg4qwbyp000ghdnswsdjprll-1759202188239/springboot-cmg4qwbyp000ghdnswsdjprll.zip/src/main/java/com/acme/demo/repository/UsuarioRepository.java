package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, java.util.UUID> {}
