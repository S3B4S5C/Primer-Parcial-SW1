package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;
import com.acme.demo.domain.Usuario;
import com.acme.demo.service.UsuarioService;

@CrossOrigin
@RestController
@RequestMapping("/")
public class UsuarioController {
  private final UsuarioService svc;
  public UsuarioController(UsuarioService svc) { this.svc = svc; }

  @GetMapping
  public List<Usuario> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Usuario get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping @ResponseStatus(HttpStatus.CREATED)
  public Usuario create(@RequestBody Usuario body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Usuario update(@PathVariable java.util.UUID id, @RequestBody Usuario body) {
    // naive: confía en el body.id; en real, setea body.id = id si quieres
    return svc.save(body);
  }

  @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
