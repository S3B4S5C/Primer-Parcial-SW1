package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;




@Entity
@Table(name = "libro")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Libro implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;
}
