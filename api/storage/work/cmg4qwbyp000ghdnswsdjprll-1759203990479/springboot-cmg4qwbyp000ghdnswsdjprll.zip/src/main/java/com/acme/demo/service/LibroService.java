package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Libro;
import com.acme.demo.repository.LibroRepository;

@Service
public class LibroService {
  private final LibroRepository repo;
  public LibroService(LibroRepository repo) { this.repo = repo; }

  public List<Libro> findAll() { return repo.findAll(); }
  public Optional<Libro> findById(java.util.UUID id) { return repo.findById(id); }
  public Libro save(Libro e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
